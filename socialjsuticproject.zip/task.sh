#! /bin/bash
rsync -avh /opt/dotnetcore-tools /mnt
